mydiv <- function(x,y=2) {
  result <- x/y
  return(result)
}